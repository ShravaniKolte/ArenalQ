import { useMemo, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import { BellRing, Menu, Search, Sparkles, UserCircle2 } from 'lucide-react'
import { navItems } from '../data/mockData'

interface LayoutProps {
  children: React.ReactNode
}

export function Layout({ children }: LayoutProps) {
  const location = useLocation()
  const [isSidebarOpen, setSidebarOpen] = useState(false)

  const pageTitle = useMemo(() => {
    const current = navItems.find((item) => item.path === location.pathname)
    return current?.label ?? 'ArenalQ'
  }, [location.pathname])

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_rgba(34,211,238,0.16),_transparent_35%),linear-gradient(135deg,_#020617,_#061118)] text-slate-100">
      <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-4 lg:flex-row lg:px-6 lg:py-6">
        <aside className={`rounded-[28px] border border-cyan-400/20 bg-slate-950/70 p-4 shadow-[0_0_60px_rgba(34,211,238,0.16)] backdrop-blur-xl lg:w-72 ${isSidebarOpen ? 'block' : 'hidden lg:block'}`}>
          <Link to="/" className="flex items-center gap-3 rounded-2xl border border-cyan-400/20 bg-cyan-500/10 p-3">
            <div className="rounded-xl bg-cyan-400/20 p-2">
              <Sparkles className="h-5 w-5 text-cyan-300" />
            </div>
            <div>
              <p className="text-sm font-semibold text-white">ArenalQ</p>
              <p className="text-xs text-slate-400">AI Stadium Operations Copilot</p>
            </div>
          </Link>

          <nav className="mt-6 space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) =>
                    `flex items-center gap-3 rounded-2xl px-3 py-2 text-sm transition ${isActive ? 'bg-cyan-500/20 text-cyan-200' : 'text-slate-300 hover:bg-white/10 hover:text-white'}`
                  }
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.label}</span>
                </NavLink>
              )
            })}
          </nav>

          <div className="mt-6 rounded-2xl border border-emerald-400/20 bg-emerald-500/10 p-4">
            <p className="text-sm font-semibold text-emerald-300">Live ops sync</p>
            <p className="mt-2 text-sm text-slate-300">All stadium systems are connected with AI-driven recommendations enabled.</p>
          </div>
        </aside>

        <main className="flex-1">
          <header className="flex flex-wrap items-center justify-between gap-3 rounded-[28px] border border-white/10 bg-slate-950/70 px-4 py-3 shadow-[0_0_50px_rgba(15,23,42,0.65)] backdrop-blur-xl">
            <div className="flex items-center gap-3">
              <button className="rounded-2xl border border-white/10 p-2 lg:hidden" onClick={() => setSidebarOpen((value) => !value)}>
                <Menu className="h-4 w-4 text-slate-200" />
              </button>
              <div>
                <p className="text-sm uppercase tracking-[0.2em] text-cyan-300">{pageTitle}</p>
                <p className="text-lg font-semibold text-white">FIFA World Cup 2026 control surface</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <label className="hidden items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-300 md:flex">
                <Search className="h-4 w-4" />
                <input className="w-36 bg-transparent outline-none" placeholder="Search" />
              </label>
              <button className="rounded-2xl border border-cyan-400/20 bg-cyan-500/10 p-2">
                <BellRing className="h-4 w-4 text-cyan-300" />
              </button>
              <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-3 py-2">
                <UserCircle2 className="h-5 w-5 text-slate-200" />
                <span className="text-sm text-slate-300">Ops Lead</span>
              </div>
            </div>
          </header>

          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }} className="mt-4">
            {children}
          </motion.div>
        </main>
      </div>
    </div>
  )
}
