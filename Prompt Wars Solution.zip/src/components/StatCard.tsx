import type { LucideIcon } from 'lucide-react'

interface StatCardProps {
  label: string
  value: string
  change: string
  icon: LucideIcon
  accent?: string
}

export function StatCard({ label, value, change, icon: Icon, accent = 'from-cyan-500/20 to-emerald-500/20' }: StatCardProps) {
  return (
    <div className={`rounded-2xl border border-white/10 bg-gradient-to-br ${accent} p-4 shadow-[0_0_40px_rgba(34,211,238,0.12)] backdrop-blur-xl`}>
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-300">{label}</p>
        <div className="rounded-xl border border-white/10 bg-slate-950/60 p-2">
          <Icon className="h-4 w-4 text-cyan-300" />
        </div>
      </div>
      <p className="mt-4 text-2xl font-semibold text-white">{value}</p>
      <p className="mt-1 text-sm text-emerald-300">{change}</p>
    </div>
  )
}
