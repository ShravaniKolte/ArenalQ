import { motion } from 'framer-motion'
import { AlertOctagon, HeartPulse, ShieldCheck, Siren } from 'lucide-react'
import { incidents } from '../data/mockData'
import { StatCard } from '../components/StatCard'

export function SecurityDashboard() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard label="Security alerts" value="3" change="1 critical" icon={Siren} accent="from-amber-500/20 to-orange-400/10" />
        <StatCard label="Medical team" value="6 on duty" change="2 nearby" icon={HeartPulse} accent="from-emerald-500/20 to-cyan-400/10" />
        <StatCard label="Safe exits" value="14" change="Routes optimized" icon={ShieldCheck} />
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_0.95fr]">
        <section className="rounded-[28px] border border-cyan-400/20 bg-slate-950/70 p-6 backdrop-blur-xl">
          <div className="flex items-center gap-2 text-cyan-300">
            <AlertOctagon className="h-5 w-5" />
            <p className="text-sm uppercase tracking-[0.3em]">Incident command</p>
          </div>
          <h2 className="mt-3 text-2xl font-semibold text-white">AI-generated incident summaries and next actions.</h2>
          <div className="mt-6 space-y-3">
            {incidents.map((incident) => (
              <motion.div whileHover={{ y: -3 }} key={incident.id} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-white">{incident.title}</p>
                  <span className="text-xs uppercase tracking-[0.25em] text-amber-300">{incident.severity}</span>
                </div>
                <p className="mt-2 text-sm text-slate-300">{incident.id} • AI summary: safe exit lanes are clear and response teams are rerouted.</p>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="rounded-[28px] border border-white/10 bg-slate-950/70 p-6 backdrop-blur-xl">
          <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">Emergency map</p>
          <div className="mt-6 grid h-56 grid-cols-2 gap-3 rounded-[24px] border border-white/10 bg-[radial-gradient(circle_at_top,_rgba(248,113,113,0.16),_transparent_60%)] p-4">
            <div className="rounded-2xl border border-amber-400/20 bg-amber-500/10 p-3 text-sm text-amber-200">North exit</div>
            <div className="rounded-2xl border border-cyan-400/20 bg-cyan-500/10 p-3 text-sm text-cyan-200">Medical suite</div>
            <div className="rounded-2xl border border-emerald-400/20 bg-emerald-500/10 p-3 text-sm text-emerald-200">Safe checkpoint</div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-sm text-slate-200">Command desk</div>
          </div>
        </section>
      </div>
    </div>
  )
}
