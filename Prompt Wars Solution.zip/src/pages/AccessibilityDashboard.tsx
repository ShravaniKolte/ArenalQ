import { motion } from 'framer-motion'
import { Accessibility, Ear, MessageSquareText, Mic, Sparkles } from 'lucide-react'
import { StatCard } from '../components/StatCard'

export function AccessibilityDashboard() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard label="Accessible routes" value="12" change="Wheelchair optimized" icon={Accessibility} />
        <StatCard label="Live captions" value="99%" change="Real-time accuracy" icon={MessageSquareText} accent="from-cyan-500/20 to-cyan-400/10" />
        <StatCard label="Audio support" value="24/7" change="Multilingual descriptions" icon={Ear} accent="from-emerald-500/20 to-cyan-400/10" />
      </div>

      <section className="rounded-[28px] border border-cyan-400/20 bg-slate-950/70 p-6 backdrop-blur-xl">
        <div className="flex items-center gap-2 text-cyan-300">
          <Sparkles className="h-5 w-5" />
          <p className="text-sm uppercase tracking-[0.3em]">Accessibility experience</p>
        </div>
        <div className="mt-6 grid gap-6 lg:grid-cols-[0.95fr_1.05fr]">
          <div className="space-y-3">
            {[
              'Wheelchair-friendly routing with elevator-aware guidance.',
              'Live captions and text simplification for clearer announcements.',
              'Voice navigation with high-contrast mode for low-vision guests.',
            ].map((item) => (
              <motion.div whileHover={{ x: 4 }} key={item} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-300">
                {item}
              </motion.div>
            ))}
          </div>
          <div className="rounded-[24px] border border-white/10 bg-gradient-to-br from-cyan-500/10 to-emerald-500/10 p-4">
            <div className="flex items-center gap-2 text-cyan-300">
              <Mic className="h-5 w-5" />
              <p className="text-sm font-semibold uppercase tracking-[0.3em]">Voice navigation</p>
            </div>
            <p className="mt-3 text-lg font-semibold text-white">“Guide me to the accessible entrance and quieter seating area.”</p>
            <p className="mt-2 text-sm text-slate-300">The system is routing you through the lift corridor with the lowest congestion and best acoustic comfort.</p>
          </div>
        </div>
      </section>
    </div>
  )
}
