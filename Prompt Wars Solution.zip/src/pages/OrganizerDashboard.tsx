import { Activity, AlertTriangle, Users as UsersIcon, Zap } from 'lucide-react'
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar, PieChart, Pie, Cell } from 'recharts'
import { crowdSeries, incidents, queueSeries, sustainabilitySeries } from '../data/mockData'
import { StatCard } from '../components/StatCard'

const pieColors = ['#22d3ee', '#34d399', '#818cf8', '#f59e0b']

export function OrganizerDashboard() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        <StatCard label="Crowd density" value="82%" change="Peak demand ahead" icon={Activity} />
        <StatCard label="Active incidents" value="3" change="1 high priority" icon={AlertTriangle} accent="from-amber-500/20 to-orange-400/10" />
        <StatCard label="Volunteer coverage" value="94%" change="All zones staffed" icon={UsersIcon} accent="from-emerald-500/20 to-cyan-400/10" />
        <StatCard label="AI recommendations" value="17" change="Resource actions queued" icon={Zap} accent="from-violet-500/20 to-cyan-400/10" />
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
        <section className="rounded-[28px] border border-white/10 bg-slate-950/70 p-6 backdrop-blur-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">Crowd intelligence</p>
              <h2 className="mt-1 text-xl font-semibold text-white">Live density forecasting</h2>
            </div>
            <div className="rounded-full border border-cyan-400/20 bg-cyan-500/10 px-3 py-1 text-sm text-cyan-300">AI alert: crowd surge at 15:00</div>
          </div>
          <div className="mt-6 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={crowdSeries}>
                <CartesianGrid stroke="#1f2937" strokeDasharray="3 3" />
                <XAxis dataKey="name" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="#22d3ee" strokeWidth={3} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="rounded-[28px] border border-white/10 bg-slate-950/70 p-6 backdrop-blur-xl">
          <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">Operational brief</p>
          <div className="mt-4 space-y-3">
            {incidents.map((incident) => (
              <div key={incident.id} className="rounded-2xl border border-white/10 bg-white/5 p-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-white">{incident.title}</p>
                  <span className="text-xs uppercase tracking-[0.25em] text-cyan-300">{incident.severity}</span>
                </div>
                <p className="mt-1 text-sm text-slate-400">{incident.id} • {incident.time}</p>
              </div>
            ))}
          </div>
        </section>
      </div>

      <div className="grid gap-6 lg:grid-cols-[0.95fr_1.05fr]">
        <section className="rounded-[28px] border border-white/10 bg-slate-950/70 p-6 backdrop-blur-xl">
          <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">Queue health</p>
          <div className="mt-6 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={queueSeries}>
                <CartesianGrid stroke="#1f2937" strokeDasharray="3 3" />
                <XAxis dataKey="name" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip />
                <Bar dataKey="value" radius={[8, 8, 0, 0]} fill="#34d399" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="rounded-[28px] border border-white/10 bg-slate-950/70 p-6 backdrop-blur-xl">
          <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">Resource mix</p>
          <div className="mt-6 flex h-64 items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={queueSeries} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90} paddingAngle={3}>
                  {queueSeries.map((entry, index) => (
                    <Cell key={entry.name} fill={pieColors[index % pieColors.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </section>
      </div>

      <section className="rounded-[28px] border border-white/10 bg-slate-950/70 p-6 backdrop-blur-xl">
        <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">Sustainability pulse</p>
        <div className="mt-6 h-72">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={sustainabilitySeries}>
              <CartesianGrid stroke="#1f2937" strokeDasharray="3 3" />
              <XAxis dataKey="name" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip />
              <Line type="monotone" dataKey="energy" stroke="#22d3ee" strokeWidth={2} />
              <Line type="monotone" dataKey="water" stroke="#34d399" strokeWidth={2} />
              <Line type="monotone" dataKey="waste" stroke="#f59e0b" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>
    </div>
  )
}
