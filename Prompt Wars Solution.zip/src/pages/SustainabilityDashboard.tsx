import { motion } from 'framer-motion'
import { Droplets, Leaf, Recycle, Zap } from 'lucide-react'
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts'
import { sustainabilitySeries } from '../data/mockData'
import { StatCard } from '../components/StatCard'

export function SustainabilityDashboard() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        <StatCard label="Energy" value="142 kWh" change="-8% vs target" icon={Zap} />
        <StatCard label="Water" value="84 L" change="Steady usage" icon={Droplets} accent="from-cyan-500/20 to-cyan-400/10" />
        <StatCard label="Waste" value="45 kg" change="Low contamination" icon={Recycle} accent="from-emerald-500/20 to-cyan-400/10" />
        <StatCard label="Carbon" value="1.8 t" change="On track" icon={Leaf} accent="from-violet-500/20 to-cyan-400/10" />
      </div>

      <section className="rounded-[28px] border border-cyan-400/20 bg-slate-950/70 p-6 backdrop-blur-xl">
        <div className="flex items-center gap-2 text-cyan-300">
          <Leaf className="h-5 w-5" />
          <p className="text-sm uppercase tracking-[0.3em]">Sustainability intelligence</p>
        </div>
        <div className="mt-6 h-80">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={sustainabilitySeries}>
              <CartesianGrid stroke="#1f2937" strokeDasharray="3 3" />
              <XAxis dataKey="name" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip />
              <Area type="monotone" dataKey="energy" stroke="#22d3ee" fill="#22d3ee" fillOpacity={0.2} />
              <Area type="monotone" dataKey="water" stroke="#34d399" fill="#34d399" fillOpacity={0.2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        {[
          'AI recommends shifting refrigeration loads to off-peak windows.',
          'Water refill stations reduce single-use plastic by 18% this week.',
        ].map((item) => (
          <motion.div whileHover={{ y: -3 }} key={item} className="rounded-[24px] border border-white/10 bg-slate-950/70 p-4 text-sm text-slate-300 backdrop-blur-xl">
            {item}
          </motion.div>
        ))}
      </div>
    </div>
  )
}
