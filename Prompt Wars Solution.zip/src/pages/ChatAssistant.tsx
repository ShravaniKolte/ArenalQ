import { useState } from 'react'
import { Bot, Mic, SendHorizonal, Sparkles } from 'lucide-react'
import { chatPrompts, languageOptions, getTranslation } from '../data/mockData'
import { askAssistant, executeFunction } from '../services/genaiMock'
import type { Message } from '../services/genaiMock'

export function ChatAssistant() {
  const [input, setInput] = useState('')
  const [selectedLanguage, setSelectedLanguage] = useState('English')
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: 'ArenalQ is ready. Ask for venue navigation, queue insights, or operational guidance.',
    },
  ])
  const [isThinking, setIsThinking] = useState(false)

  const handleSend = async () => {
    if (!input.trim()) return
    const userMsg: Message = { role: 'user', content: input }
    setMessages((current) => [...current, userMsg])
    setInput('')
    setIsThinking(true)

    try {
      const response = await askAssistant(input, [], selectedLanguage)
      setMessages((current) => [...current, response.message])

      const fc = response.functionCall
      if (fc) {
        const exec = await executeFunction(fc.name, fc.args)
        setMessages((current) => [
          ...current,
          { role: 'assistant', content: `Executed: ${fc.name} → ${JSON.stringify(exec)}` },
        ])
      }
    } catch (err) {
      setMessages((current) => [...current, { role: 'assistant', content: 'Sorry, something went wrong.' }])
    } finally {
      setIsThinking(false)
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[0.85fr_1.15fr]">
      <section className="rounded-[28px] border border-cyan-400/20 bg-slate-950/70 p-6 backdrop-blur-xl">
        <div className="flex items-center gap-2 text-cyan-300">
          <Bot className="h-5 w-5" />
          <p className="text-sm uppercase tracking-[0.3em]">AI assistant</p>
        </div>
        <h2 className="mt-3 text-2xl font-semibold text-white">Conversational operations copilot</h2>
        <p className="mt-3 text-sm text-slate-300">Use GPT-style assistance with RAG grounding, voice support, and multilingual responses.</p>
        <div className="mt-6 space-y-3">
          {chatPrompts.map((prompt) => (
            <button key={prompt} onClick={() => setInput(prompt)} className="w-full rounded-2xl border border-white/10 bg-white/5 p-3 text-left text-sm text-slate-300 transition hover:bg-white/10">
              {prompt}
            </button>
          ))}
        </div>
        <div className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-4">
          <p className="text-sm font-semibold text-white">Multilingual support</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {languageOptions.map((language) => (
              <button
                key={language}
                onClick={() => setSelectedLanguage(language)}
                className={`rounded-full px-2 py-1 text-xs transition cursor-pointer ${
                  selectedLanguage === language
                    ? 'border-cyan-400 bg-cyan-500/30 text-cyan-100 border'
                    : 'border border-cyan-400/20 bg-cyan-500/10 text-cyan-200 hover:bg-cyan-500/20'
                }`}
              >
                {language}
              </button>
            ))}
          </div>
          <p className="mt-3 text-xs text-slate-400">Selected: {selectedLanguage}</p>
        </div>
      </section>

      <section className="rounded-[28px] border border-white/10 bg-slate-950/70 p-6 backdrop-blur-xl">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">Live conversation</p>
            <p className="text-xl font-semibold text-white">Context-aware support</p>
          </div>
          <div className="rounded-full border border-emerald-400/20 bg-emerald-500/10 px-3 py-1 text-sm text-emerald-300">
            <Sparkles className="mr-2 inline h-4 w-4" />
            Function calling ready
          </div>
        </div>

        <div className="mt-6 flex h-[28rem] flex-col gap-3 overflow-y-auto rounded-[24px] border border-white/10 bg-slate-900/70 p-4">
          {messages.map((message, index) => (
            <div key={`${message.role}-${index}`} className={`max-w-[85%] rounded-2xl p-3 text-sm ${message.role === 'assistant' ? 'bg-cyan-500/10 text-cyan-100' : 'ml-auto bg-emerald-500/10 text-emerald-100'}`}>
              {message.content}
            </div>
          ))}
          {isThinking && (
            <div className="max-w-[60%] animate-pulse rounded-2xl p-3 text-sm bg-cyan-500/5 text-cyan-100">Thinking…</div>
          )}
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2 rounded-[24px] border border-white/10 bg-white/5 p-3">
          <button className="rounded-2xl border border-white/10 bg-white/5 p-2">
            <Mic className="h-4 w-4 text-cyan-300" />
          </button>
          <input value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => event.key === 'Enter' && handleSend()} className="flex-1 bg-transparent text-sm text-slate-200 outline-none" placeholder="Ask about gates, food, traffic, or incidents" />
          <button onClick={handleSend} className="rounded-2xl bg-cyan-400 p-2 text-slate-950">
            <SendHorizonal className="h-4 w-4" />
          </button>
        </div>
      </section>
    </div>
  )
}
