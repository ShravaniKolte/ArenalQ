import { motion } from 'framer-motion'
import { Headphones, ShieldAlert, Sparkles, Stethoscope } from 'lucide-react'
import { volunteerTasks } from '../data/mockData'
import { StatCard } from '../components/StatCard'

export function VolunteerDashboard() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
        <section className="rounded-[28px] border border-cyan-400/20 bg-slate-950/70 p-6 backdrop-blur-xl">
          <div className="flex items-center gap-2 text-cyan-300">
            <Sparkles className="h-5 w-5" />
            <p className="text-sm uppercase tracking-[0.3em]">Volunteer copilot</p>
          </div>
          <h2 className="mt-3 text-2xl font-semibold text-white">Fast, voice-first guidance for every critical moment.</h2>
          <p className="mt-3 text-sm text-slate-300">Retrieve SOPs, follow emergency procedures, and activate rapid response playbooks without leaving the field.</p>
          <div className="mt-6 space-y-3">
            {volunteerTasks.map((task) => (
              <motion.div whileHover={{ x: 4 }} key={task.title} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <p className="text-sm font-semibold text-white">{task.title}</p>
                <p className="mt-1 text-sm text-slate-300">{task.detail}</p>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="rounded-[28px] border border-white/10 bg-slate-950/70 p-6 backdrop-blur-xl">
          <div className="rounded-[24px] border border-white/10 bg-gradient-to-br from-cyan-500/10 to-emerald-500/10 p-4">
            <div className="flex items-center gap-2 text-cyan-300">
              <Headphones className="h-5 w-5" />
              <p className="text-sm font-semibold uppercase tracking-[0.3em]">Voice assistant</p>
            </div>
            <p className="mt-3 text-lg font-semibold text-white">“Summon medical support to concourse B.”</p>
            <p className="mt-2 text-sm text-slate-300">The assistant will verify the closest team, open the incident card, and send the action to the response channel.</p>
          </div>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="flex items-center gap-2 text-emerald-300">
                <ShieldAlert className="h-4 w-4" />
                <p className="text-sm font-semibold">Emergency ready</p>
              </div>
              <p className="mt-3 text-sm text-slate-300">3 protected routes currently active.</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="flex items-center gap-2 text-cyan-300">
                <Stethoscope className="h-4 w-4" />
                <p className="text-sm font-semibold">Medical support</p>
              </div>
              <p className="mt-3 text-sm text-slate-300">Nearest unit 90 seconds away.</p>
            </div>
          </div>
        </section>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <StatCard label="SOP matches" value="24" change="Updated live" icon={Sparkles} />
        <StatCard label="Response time" value="90s" change="Average dispatch" icon={ShieldAlert} accent="from-emerald-500/20 to-cyan-400/10" />
        <StatCard label="Knowledge retrieval" value="99.2%" change="RAG confidence" icon={Headphones} accent="from-violet-500/20 to-cyan-400/10" />
      </div>
    </div>
  )
}
