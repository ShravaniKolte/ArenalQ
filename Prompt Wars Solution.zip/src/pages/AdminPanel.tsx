import { motion } from 'framer-motion'
import { ShieldCheck, Sparkles, Users, Wrench } from 'lucide-react'
import { StatCard } from '../components/StatCard'

export function AdminPanel() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        <StatCard label="System health" value="98.4%" change="Fully online" icon={ShieldCheck} />
        <StatCard label="Active users" value="1,842" change="+12% today" icon={Users} accent="from-cyan-500/20 to-cyan-400/10" />
        <StatCard label="AI modules" value="9" change="All active" icon={Sparkles} accent="from-emerald-500/20 to-cyan-400/10" />
        <StatCard label="Maintenance" value="Nominal" change="No escalations" icon={Wrench} accent="from-violet-500/20 to-cyan-400/10" />
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <section className="rounded-[28px] border border-white/10 bg-slate-950/70 p-6 backdrop-blur-xl">
          <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">Configuration</p>
          <div className="mt-6 space-y-3">
            {[
              'Permission matrix synchronized for all stadium roles.',
              'AI policy controls reviewed for voice and chatbot traffic.',
              'Real-time connectors aligned to occupancy and transport feeds.',
            ].map((item) => (
              <motion.div whileHover={{ x: 4 }} key={item} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-300">
                {item}
              </motion.div>
            ))}
          </div>
        </section>

        <section className="rounded-[28px] border border-cyan-400/20 bg-slate-950/70 p-6 backdrop-blur-xl">
          <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">Command center</p>
          <div className="mt-6 rounded-[24px] border border-white/10 bg-gradient-to-br from-cyan-500/10 to-emerald-500/10 p-4">
            <p className="text-lg font-semibold text-white">Admin override panel</p>
            <p className="mt-2 text-sm text-slate-300">Lock down incidents, adjust staffing recommendations, and enable special-event workflows from a single place.</p>
          </div>
        </section>
      </div>
    </div>
  )
}
