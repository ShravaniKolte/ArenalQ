import { motion } from 'framer-motion'
import { Compass, MapPinned, Sparkles, UtensilsCrossed, Waves } from 'lucide-react'
import { fanActions } from '../data/mockData'
import { StatCard } from '../components/StatCard'

export function FanDashboard() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
        <section className="rounded-[28px] border border-cyan-400/20 bg-slate-950/70 p-6 backdrop-blur-xl">
          <div className="flex items-center gap-2 text-cyan-300">
            <Sparkles className="h-5 w-5" />
            <p className="text-sm uppercase tracking-[0.3em]">Fan assistant</p>
          </div>
          <h2 className="mt-3 text-2xl font-semibold text-white">Everything you need in one conversational layer.</h2>
          <p className="mt-3 text-sm text-slate-300">Navigate the venue, receive food guidance, find restrooms, and personalize your route in 100+ languages.</p>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            {fanActions.map((action) => (
              <motion.div whileHover={{ y: -3 }} key={action.title} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <p className="text-sm font-semibold text-white">{action.title}</p>
                <p className="mt-2 text-sm text-slate-300">{action.description}</p>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="rounded-[28px] border border-white/10 bg-slate-950/70 p-6 backdrop-blur-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">Navigation map</p>
              <p className="mt-1 text-xl font-semibold text-white">Seat finder & gate guidance</p>
            </div>
            <div className="rounded-2xl border border-emerald-400/20 bg-emerald-500/10 p-2">
              <MapPinned className="h-5 w-5 text-emerald-300" />
            </div>
          </div>
          <div className="mt-6 grid h-56 grid-cols-3 gap-3 rounded-[24px] border border-white/10 bg-[radial-gradient(circle_at_top,_rgba(34,211,238,0.18),_transparent_60%)] p-4">
            <div className="rounded-2xl border border-cyan-400/20 bg-cyan-500/10 p-3 text-center text-sm text-cyan-200">North Gate</div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center text-sm text-slate-200">Section 121</div>
            <div className="rounded-2xl border border-emerald-400/20 bg-emerald-500/10 p-3 text-center text-sm text-emerald-200">Food Hall</div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center text-sm text-slate-200">Restrooms</div>
            <div className="rounded-2xl border border-cyan-400/20 bg-cyan-500/10 p-3 text-center text-sm text-cyan-200">East Exit</div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center text-sm text-slate-200">Parking</div>
          </div>
        </section>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <StatCard label="Queue prediction" value="9 min" change="Fastest route available" icon={Compass} accent="from-cyan-500/20 to-cyan-400/10" />
        <StatCard label="Dining recommendation" value="2 min" change="Peak pickup window avoided" icon={UtensilsCrossed} accent="from-emerald-500/20 to-emerald-400/10" />
        <StatCard label="Transport guidance" value="12 mins" change="Rail + walk optimized" icon={Waves} accent="from-violet-500/20 to-cyan-400/10" />
      </div>
    </div>
  )
}
