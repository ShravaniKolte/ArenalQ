import { motion } from 'framer-motion'
import { ArrowRight, Bot, ShieldCheck, Sparkles, Users, Waves } from 'lucide-react'
import { heroStats } from '../data/mockData'

export function LandingPage() {
  return (
    <div className="space-y-6">
      <section className="overflow-hidden rounded-[32px] border border-cyan-400/20 bg-slate-950/70 p-6 shadow-[0_0_80px_rgba(34,211,238,0.16)] backdrop-blur-xl lg:p-8">
        <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-cyan-400/30 bg-cyan-500/10 px-3 py-1 text-sm text-cyan-300">
              <Sparkles className="h-4 w-4" />
              FIFA World Cup 2026 • AI-first stadium operations
            </div>
            <h1 className="mt-5 text-4xl font-semibold tracking-tight text-white sm:text-5xl">
              ArenalQ brings every stadium team under one intelligent command center.
            </h1>
            <p className="mt-4 max-w-2xl text-lg text-slate-300">
              From fan navigation to incident response and sustainability tracking, the platform turns every operational signal into proactive guidance.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="/fan" className="inline-flex items-center gap-2 rounded-full bg-cyan-400 px-4 py-2 text-sm font-semibold text-slate-950 transition hover:bg-cyan-300">
                Explore fan experience <ArrowRight className="h-4 w-4" />
              </a>
              <a href="/analytics" className="rounded-full border border-white/10 px-4 py-2 text-sm font-semibold text-slate-200 transition hover:bg-white/10">
                Review analytics
              </a>
            </div>
          </div>

          <div className="rounded-[28px] border border-white/10 bg-gradient-to-br from-cyan-500/20 to-emerald-500/20 p-5">
            <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">Live center</p>
            <div className="mt-4 grid gap-3">
              {heroStats.map((item) => (
                <div key={item.label} className="rounded-2xl border border-white/10 bg-slate-950/60 p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-slate-300">{item.label}</p>
                    <span className="text-sm text-emerald-300">{item.change}</span>
                  </div>
                  <p className="mt-2 text-2xl font-semibold text-white">{item.value}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        {[
          { icon: Users, title: 'Fan experience', text: 'Personalized route planning and multilingual assistance.' },
          { icon: ShieldCheck, title: 'Security readiness', text: 'Live incident summaries with safe-exit guidance.' },
          { icon: Waves, title: 'Predictive analytics', text: 'Crowd and sustainability forecasting in real time.' },
        ].map((item) => {
          const Icon = item.icon
          return (
            <motion.div key={item.title} whileHover={{ y: -4, scale: 1.01 }} className="rounded-[24px] border border-white/10 bg-slate-950/70 p-5 backdrop-blur-xl">
              <div className="rounded-2xl border border-cyan-400/20 bg-cyan-500/10 p-3 w-fit">
                <Icon className="h-5 w-5 text-cyan-300" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-white">{item.title}</h3>
              <p className="mt-2 text-sm text-slate-300">{item.text}</p>
            </motion.div>
          )
        })}
      </section>

      <section className="rounded-[32px] border border-white/10 bg-slate-950/70 p-6 backdrop-blur-xl">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">Mission-ready</p>
            <h2 className="mt-1 text-2xl font-semibold text-white">Operational modules across the venue</h2>
          </div>
          <div className="rounded-full border border-emerald-400/20 bg-emerald-500/10 px-3 py-1 text-sm text-emerald-300">
            <Bot className="mr-2 inline h-4 w-4" />
            RAG + GenAI ready
          </div>
        </div>
        <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {['Fan assistant', 'Organizer copilot', 'Volunteer knowledge base', 'Accessibility routing'].map((item) => (
            <div key={item} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-300">
              {item}
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
