import {
  Activity,
  AlertTriangle,
  BellRing,
  Bot,
  Car,
  Droplets,
  Leaf,
  ShieldCheck,
  Sparkles,
  Users,
  Waves,
  Zap,
} from 'lucide-react'

export const navItems = [
  { label: 'Landing', path: '/', icon: Sparkles },
  { label: 'Fan', path: '/fan', icon: Users },
  { label: 'Organizer', path: '/organizer', icon: Activity },
  { label: 'Volunteer', path: '/volunteer', icon: ShieldCheck },
  { label: 'Security', path: '/security', icon: AlertTriangle },
  { label: 'Accessibility', path: '/accessibility', icon: Bot },
  { label: 'Sustainability', path: '/sustainability', icon: Leaf },
  { label: 'AI Chat', path: '/chat', icon: Bot },
  { label: 'Admin', path: '/admin', icon: Zap },
  { label: 'Analytics', path: '/analytics', icon: Waves },
]

export const heroStats = [
  { label: 'Crowd density', value: '82%', change: '+6% vs kickoff' },
  { label: 'Avg queue', value: '9 min', change: '-2 min' },
  { label: 'Parking', value: '68%', change: 'Open lanes active' },
  { label: 'Sustainability', value: '94%', change: 'Green target on track' },
]

export const crowdSeries = [
  { name: '10:00', value: 42 },
  { name: '11:00', value: 58 },
  { name: '12:00', value: 67 },
  { name: '13:00', value: 73 },
  { name: '14:00', value: 81 },
  { name: '15:00', value: 89 },
]

export const queueSeries = [
  { name: 'North', value: 10 },
  { name: 'West', value: 6 },
  { name: 'East', value: 8 },
  { name: 'VIP', value: 3 },
]

export const sustainabilitySeries = [
  { name: 'Mon', energy: 182, water: 118, waste: 67 },
  { name: 'Tue', energy: 175, water: 110, waste: 60 },
  { name: 'Wed', energy: 163, water: 98, waste: 56 },
  { name: 'Thu', energy: 169, water: 103, waste: 58 },
  { name: 'Fri', energy: 154, water: 91, waste: 49 },
  { name: 'Sat', energy: 142, water: 84, waste: 45 },
]

export const incidents = [
  { id: 'INC-204', title: 'Medical response dispatched', severity: 'High', time: '2 min ago' },
  { id: 'INC-205', title: 'Queue spike at Gate C', severity: 'Medium', time: '8 min ago' },
  { id: 'INC-206', title: 'Accessibility lane cleared', severity: 'Low', time: '14 min ago' },
]

export const fanActions = [
  { title: 'Find my seat', description: 'Navigate from gate to section with turn-by-turn guidance.' },
  { title: 'Food recommendation', description: 'Nearest vegan kitchen with the fastest pickup time.' },
  { title: 'Lost & found', description: 'Submit a photo and receive recovery guidance instantly.' },
]

export const volunteerTasks = [
  { title: 'Lost child workflow', detail: 'Activate protocol and notify family reunification desk.' },
  { title: 'Medical SOP', detail: 'Summon first responder and preserve emergency access lane.' },
  { title: 'Crowd guidance', detail: 'Redirect fans from high-density concourse to safe zones.' },
]

export const alerts = [
  { label: 'Security', value: '3 active', icon: ShieldCheck },
  { label: 'Parking', value: '68% full', icon: Car },
  { label: 'Water', value: '92% stable', icon: Droplets },
  { label: 'Notifications', value: '12 new', icon: BellRing },
]

export const chatPrompts = [
  'Guide me to Gate 6 from section 121.',
  'What is the fastest food pick-up near my seat?',
  'Summarize the latest security incident.',
]

export function getTranslation(key: string, language: string = 'en'): string {
  const langCode = languageMap[language] || 'en'
  return translations[langCode]?.[key] || translations.en[key] || key
}

export const languageOptions = [
  'English',
  'Español',
  'Français',
  'Deutsch',
  'Português',
  'العربية',
  '日本語',
  '한국어',
  '中文',
  'हिन्दी',
]

export const languageMap: Record<string, string> = {
  'English': 'en',
  'Español': 'es',
  'Français': 'fr',
  'Deutsch': 'de',
  'Português': 'pt',
  'العربية': 'ar',
  '日本語': 'ja',
  '한국어': 'ko',
  '中文': 'zh',
  'हिन्दी': 'hi',
}

export const translations: Record<string, Record<string, string>> = {
  en: {
    'nav_landing': 'Landing',
    'nav_fan': 'Fan',
    'nav_chat': 'AI Chat',
    'assistant_ready': 'ArenalQ is ready. Ask for venue navigation, queue insights, or operational guidance.',
    'assistant_title': 'Conversational operations copilot',
    'assistant_desc': 'Use GPT-style assistance with RAG grounding, voice support, and multilingual responses.',
    'chat_placeholder': 'Ask about gates, food, traffic, or incidents',
    'prompt_1': 'Guide me to Gate 6 from section 121.',
    'prompt_2': 'What is the fastest food pick-up near my seat?',
    'prompt_3': 'Summarize the latest security incident.',
    'response_gate': 'Recommended route: follow signs to Gate C → concourse 3 → elevators to Section 121. Estimated walk: 6 minutes. Current wait at security: 4 minutes.',
    'response_food': 'Nearest vegan stall: GreenBites (Concourse West). Estimated pickup time: 2 minutes. Would you like me to notify them to start preparing?',
    'response_security': 'Recent incidents summary retrieved. INC-204 requires immediate verification. Medical unit ETA: 2 minutes. I recommend escalating to incident command.',
    'thinking': 'Thinking…',
  },
  es: {
    'nav_landing': 'Inicio',
    'nav_fan': 'Aficionado',
    'nav_chat': 'Chat IA',
    'assistant_ready': 'ArenalQ está listo. Pregunta sobre navegación del estadio, información de colas o orientación operativa.',
    'assistant_title': 'Copiloto de operaciones conversacionales',
    'assistant_desc': 'Utiliza asistencia estilo GPT con base RAG, soporte de voz y respuestas multilingües.',
    'chat_placeholder': 'Pregunta sobre puertas, comida, tráfico o incidentes',
    'prompt_1': 'Guíame a la Puerta 6 desde la sección 121.',
    'prompt_2': '¿Cuál es la recogida de comida más rápida cerca de mi asiento?',
    'prompt_3': 'Resumir el incidente de seguridad más reciente.',
    'response_gate': 'Ruta recomendada: siga las señales hacia Puerta C → concourse 3 → ascensores a Sección 121. Tiempo estimado de caminata: 6 minutos. Espera actual en seguridad: 4 minutos.',
    'response_food': 'Puesto vegano más cercano: GreenBites (Concourse Oeste). Tiempo estimado de recogida: 2 minutos. ¿Desea que los notifique para comenzar a preparar?',
    'response_security': 'Resumen de incidentes recuperado. INC-204 requiere verificación inmediata. ETA de unidad médica: 2 minutos.',
    'thinking': 'Pensando…',
  },
  fr: {
    'nav_landing': 'Accueil',
    'nav_fan': 'Fan',
    'nav_chat': 'Chat IA',
    'assistant_ready': 'ArenalQ est prêt. Demandez la navigation du stade, des informations sur les files d\'attente ou des conseils opérationnels.',
    'assistant_title': 'Copilote opérationnel conversationnel',
    'assistant_desc': 'Utilisez l\'assistance de type GPT avec ancrage RAG, support vocal et réponses multilingues.',
    'chat_placeholder': 'Posez des questions sur les portes, la nourriture, le trafic ou les incidents',
    'prompt_1': 'Guide-moi à la Porte 6 depuis la section 121.',
    'prompt_2': 'Quel est le retrait de nourriture le plus rapide près de mon siège?',
    'prompt_3': 'Résumer l\'incident de sécurité le plus récent.',
    'response_gate': 'Itinéraire recommandé: suivez les panneaux vers la Porte C → concourse 3 → ascenseurs vers la Section 121. Durée estimée de la marche: 6 minutes. Temps d\'attente actuel à la sécurité: 4 minutes.',
    'response_food': 'Stand végétal le plus proche: GreenBites (Concourse Ouest). Temps de retrait estimé: 2 minutes. Voulez-vous que je les prévienne pour commencer à préparer?',
    'response_security': 'Résumé des incidents récupéré. INC-204 nécessite une vérification immédiate. ETA de l\'unité médicale: 2 minutes.',
    'thinking': 'Réflexion…',
  },
  de: {
    'nav_landing': 'Startseite',
    'nav_fan': 'Fan',
    'nav_chat': 'KI-Chat',
    'assistant_ready': 'ArenalQ ist bereit. Fragen Sie nach Stadionnavigation, Warteschlangen-Einblicken oder operativer Anleitung.',
    'assistant_title': 'Conversational Operations Copilot',
    'assistant_desc': 'Verwenden Sie GPT-ähnliche Unterstützung mit RAG-Verankerung, Sprachunterstützung und mehrsprachigen Antworten.',
    'chat_placeholder': 'Fragen Sie nach Toren, Essen, Verkehr oder Zwischenfällen',
    'prompt_1': 'Führe mich vom Sektor 121 zu Tor 6.',
    'prompt_2': 'Was ist die schnellste Lebensmittelabholung in meiner Nähe?',
    'prompt_3': 'Aktuelle Sicherheitszwischenfälle zusammenfassen.',
    'response_gate': 'Empfohlene Route: Folgen Sie den Schildern zu Tor C → Concourse 3 → Aufzüge zu Sektor 121. Geschätzte Gehzeit: 6 Minuten. Aktuelle Wartezeit bei der Sicherheit: 4 Minuten.',
    'response_food': 'Nächster vegetarischer Stand: GreenBites (Concourse West). Geschätzte Abholzeit: 2 Minuten. Soll ich sie benachrichtigen, um mit der Zubereitung zu beginnen?',
    'response_security': 'Zusammenfassung der Zwischenfälle abgerufen. INC-204 erfordert sofortige Überprüfung. ETA der medizinischen Einheit: 2 Minuten.',
    'thinking': 'Denken…',
  },
  pt: {
    'nav_landing': 'Início',
    'nav_fan': 'Fã',
    'nav_chat': 'Chat IA',
    'assistant_ready': 'ArenalQ está pronto. Pergunte sobre navegação do estádio, informações de fila ou orientação operacional.',
    'assistant_title': 'Copiloto operacional conversacional',
    'assistant_desc': 'Use assistência no estilo GPT com aterramento RAG, suporte de voz e respostas multilíngues.',
    'chat_placeholder': 'Pergunte sobre portões, comida, tráfego ou incidentes',
    'prompt_1': 'Guie-me até o Portão 6 da seção 121.',
    'prompt_2': 'Qual é a coleta de comida mais rápida perto do meu assento?',
    'prompt_3': 'Resumir o incidente de segurança mais recente.',
    'response_gate': 'Rota recomendada: siga as placas para o Portão C → concourse 3 → elevadores para a Seção 121. Tempo de caminhada estimado: 6 minutos. Tempo de espera atual na segurança: 4 minutos.',
    'response_food': 'Barraca vegetariana mais próxima: GreenBites (Concourse Oeste). Tempo de coleta estimado: 2 minutos. Deseja que eu os notifique para começar a preparar?',
    'response_security': 'Resumo de incidentes recuperado. INC-204 requer verificação imediata. ETA da unidade médica: 2 minutos.',
    'thinking': 'Pensando…',
  },
  ar: {
    'nav_landing': 'الرئيسية',
    'nav_fan': 'معجب',
    'nav_chat': 'دردشة ذكاء اصطناعي',
    'assistant_ready': 'ArenalQ جاهز. اسأل عن ملاحة الملعب أو معلومات الطوابير أو الإرشادات التشغيلية.',
    'assistant_title': 'مساعد العمليات الحواري',
    'assistant_desc': 'استخدم مساعدة على غرار GPT مع تثبيت RAG ودعم صوتي واستجابات متعددة اللغات.',
    'chat_placeholder': 'اسأل عن البوابات أو الطعام أو المرور أو الحوادث',
    'prompt_1': 'وجهني إلى البوابة 6 من القسم 121.',
    'prompt_2': 'ما أسرع استلام طعام بالقرب من مقعدي؟',
    'prompt_3': 'ملخص حادثة الأمان الأخيرة.',
    'response_gate': 'المسار الموصى به: اتبع الإشارات إلى البوابة C → الممر 3 → المصاعد إلى القسم 121. وقت المشي المقدر: 6 دقائق. وقت الانتظار الحالي عند الأمان: 4 دقائق.',
    'response_food': 'أقرب كشك نباتي: GreenBites (Concourse West). وقت الاستلام المقدر: دقيقتان. هل تريد أن أخبرهم ببدء التحضير؟',
    'response_security': 'تم استرجاع ملخص الحوادث. يتطلب INC-204 التحقق الفوري. وقت وصول الوحدة الطبية: دقيقتان.',
    'thinking': 'التفكير…',
  },
  ja: {
    'nav_landing': 'ホーム',
    'nav_fan': 'ファン',
    'nav_chat': 'AIチャット',
    'assistant_ready': 'ArenalQは準備完了です。スタジアム案内、キュー情報、または運用ガイダンスについてお質問ください。',
    'assistant_title': '会話型オペレーションコパイロット',
    'assistant_desc': 'RAGアンカー、音声サポート、多言語対応を備えたGPTスタイルの支援を使用してください。',
    'chat_placeholder': 'ゲート、食事、交通、またはインシデントについてお質問ください',
    'prompt_1': 'セクション121からゲート6へ案内してください。',
    'prompt_2': 'シートの近くで最速の食事ピックアップは何ですか？',
    'prompt_3': '最新のセキュリティインシデントを要約してください。',
    'response_gate': '推奨ルート：ゲートCへの標識に従う→コンコース3→セクション121へのエレベーター。推定歩行時間：6分。セキュリティでの現在の待機時間：4分。',
    'response_food': '最寄りのベジタリアンスタンド：GreenBites（Concourse West）。推定ピックアップ時間：2分。準備を開始するようにお知らせしますか？',
    'response_security': 'インシデント概要を取得しました。INC-204は即座の確認が必要です。医療ユニットETA：2分。',
    'thinking': '考慮中…',
  },
  ko: {
    'nav_landing': '홈',
    'nav_fan': '팬',
    'nav_chat': 'AI 채팅',
    'assistant_ready': 'ArenalQ가 준비되었습니다. 경기장 네비게이션, 대기열 정보 또는 운영 지침을 물어보세요.',
    'assistant_title': '대화형 운영 코파일럿',
    'assistant_desc': 'RAG 접지, 음성 지원 및 다국어 응답이 포함된 GPT 스타일 지원을 사용하십시오.',
    'chat_placeholder': '게이트, 음식, 교통 또는 사건에 대해 질문하세요',
    'prompt_1': '섹션 121에서 게이트 6으로 안내해주세요.',
    'prompt_2': '내 좌석 근처에서 가장 빠른 음식 픽업은 무엇입니까?',
    'prompt_3': '최근 보안 사건을 요약해주세요.',
    'response_gate': '권장 경로: 게이트 C로 가는 표지판 따라가기 → 콩코스 3 → 섹션 121로 가는 엘리베이터. 예상 도보 시간: 6분. 보안에서의 현재 대기 시간: 4분.',
    'response_food': '가장 가까운 채식 부스: GreenBites(Concourse West). 예상 픽업 시간: 2분. 준비를 시작하도록 알려드릴까요?',
    'response_security': '사건 요약을 검색했습니다. INC-204는 즉시 확인이 필요합니다. 의료 부대 ETA: 2분.',
    'thinking': '생각 중…',
  },
  zh: {
    'nav_landing': '首页',
    'nav_fan': '球迷',
    'nav_chat': 'AI聊天',
    'assistant_ready': 'ArenalQ已准备就绪。询问体育馆导航、队列信息或运营指导。',
    'assistant_title': '对话操作副驾驶',
    'assistant_desc': '使用带有RAG接地、语音支持和多语言响应的GPT风格协助。',
    'chat_placeholder': '询问关于大门、食物、交通或事件',
    'prompt_1': '请引导我从121区域到6号门。',
    'prompt_2': '我座位附近最快的食物取货是什么？',
    'prompt_3': '总结最近的安全事件。',
    'response_gate': '推荐路线：按照指示前往C门→第3通道→乘坐电梯到121区域。预计步行时间：6分钟。安检处当前等待时间：4分钟。',
    'response_food': '最近的素食摊位：GreenBites（第3通道西侧）。预计取货时间：2分钟。您想让我通知他们开始准备吗？',
    'response_security': '已检索事件摘要。INC-204需要立即验证。医疗部队ETA：2分钟。',
    'thinking': '思考中…',
  },
  hi: {
    'nav_landing': 'होम',
    'nav_fan': 'प्रशंसक',
    'nav_chat': 'एआई चैट',
    'assistant_ready': 'ArenalQ तैयार है। स्टेडियम नेविगेशन, कतार की जानकारी, या ऑपरेशनल मार्गदर्शन के बारे में पूछें।',
    'assistant_title': 'संवादी संचालन सहायक',
    'assistant_desc': 'RAG ग्राउंडिंग, वॉइस समर्थन और बहुभाषी प्रतिक्रियाओं के साथ GPT-शैली सहायता का उपयोग करें।',
    'chat_placeholder': 'गेट, भोजन, ट्रैफिक या घटनाओं के बारे में पूछें',
    'prompt_1': 'मुझे अनुभाग 121 से गेट 6 तक मार्गदर्शन करें।',
    'prompt_2': 'मेरी सीट के पास सबसे तेजी से भोजन पिकअप क्या है?',
    'prompt_3': 'हाल की सुरक्षा घटना को सारांशित करें।',
    'response_gate': 'अनुशंसित मार्ग: गेट C के संकेतों का पालन करें → कॉनकोर्स 3 → सेक्शन 121 के लिए लिफ्ट। अनुमानित चलने का समय: 6 मिनट। सुरक्षा पर वर्तमान प्रतीक्षा समय: 4 मिनट।',
    'response_food': 'निकटतम शाकाहारी स्टॉल: GreenBites (कॉनकोर्स पश्चिम)। अनुमानित पिकअप समय: 2 मिनट। क्या आप चाहते हैं कि मैं उन्हें तैयारी शुरू करने के लिए सूचित करूं?',
    'response_security': 'घटना का सारांश प्राप्त किया गया। INC-204 को तत्काल सत्यापन की आवश्यकता है। चिकित्सा इकाई ETA: 2 मिनट।',
    'thinking': 'सोच रहे हैं…',
  },
}
