import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './App.css'
import { Layout } from './components/Layout'
import { LandingPage } from './pages/LandingPage'
import { FanDashboard } from './pages/FanDashboard'
import { OrganizerDashboard } from './pages/OrganizerDashboard'
import { VolunteerDashboard } from './pages/VolunteerDashboard'
import { SecurityDashboard } from './pages/SecurityDashboard'
import { AccessibilityDashboard } from './pages/AccessibilityDashboard'
import { SustainabilityDashboard } from './pages/SustainabilityDashboard'
import { ChatAssistant } from './pages/ChatAssistant'
import { AdminPanel } from './pages/AdminPanel'
import { AnalyticsDashboard } from './pages/AnalyticsDashboard'

function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/fan" element={<FanDashboard />} />
          <Route path="/organizer" element={<OrganizerDashboard />} />
          <Route path="/volunteer" element={<VolunteerDashboard />} />
          <Route path="/security" element={<SecurityDashboard />} />
          <Route path="/accessibility" element={<AccessibilityDashboard />} />
          <Route path="/sustainability" element={<SustainabilityDashboard />} />
          <Route path="/chat" element={<ChatAssistant />} />
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="/analytics" element={<AnalyticsDashboard />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  )
}

export default App
