import { incidents, chatPrompts, getTranslation, languageMap } from '../data/mockData'

export type Message = { role: 'user' | 'assistant'; content: string }

type GenAIResponse = {
  message: Message
  functionCall?: { name: string; args: Record<string, any> }
}

// Very small rule-based mock to simulate RAG + function-calling responses
export async function askAssistant(input: string, _history: Message[], language: string = 'English'): Promise<GenAIResponse> {
  const user = input.trim()
  const langCode = languageMap[language] || 'en'
  // Simulate async latency
  await new Promise((r) => setTimeout(r, 700))

  // Simple intent matching with language support
  if (/gate|seat|section|navigate/i.test(user)) {
    return {
      message: {
        role: 'assistant',
        content: getTranslation('response_gate', language),
      },
    }
  }

  if (/food|pickup|food pick|vegan|nearest/i.test(user)) {
    return {
      message: {
        role: 'assistant',
        content: getTranslation('response_food', language),
      },
      functionCall: { name: 'notifyVendor', args: { vendorId: 'greenbites-01', prepTimeMinutes: 2 } },
    }
  }

  if (/security|incident|summarize|incident/i.test(user)) {
    return {
      message: {
        role: 'assistant',
        content: getTranslation('response_security', language),
      },
      functionCall: { name: 'createTicket', args: { priority: 'high', related: incidents[0]?.id ?? null } },
    }
  }

  // Fallback: return a helpful multi-sentence reply that references grounding
  return {
    message: {
      role: 'assistant',
      content: `I can help with venue navigation, queues, accessibility routing, and operational summaries. Try: "${chatPrompts[0]}" or "${chatPrompts[1]}".`,
    },
  }
}

// Simulated function execution for the prototype
export async function executeFunction(name: string, args: Record<string, any>) {
  await new Promise((r) => setTimeout(r, 400))
  return { status: 'ok', name, args }
}
