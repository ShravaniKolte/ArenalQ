export type Message = { role: 'user' | 'assistant'; content: string }

type GenAIResponse = {
  message: Message
  functionCall?: { name: string; args: Record<string, any> }
}

export async function askAssistant(input: string, _history: Message[], language: string = 'English'): Promise<GenAIResponse> {
  const res = await fetch('http://localhost:3001/api/chat', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ input, language }),
  })

  const data = await res.json()
  return {
    message: { role: 'assistant', content: data.reply },
    functionCall: data.functionCall,
  }
}

export async function executeFunction(name: string, args: Record<string, any>) {
  const res = await fetch('http://localhost:3001/api/execute', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ name, args }),
  })
  return res.json()
}
