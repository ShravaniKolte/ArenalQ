import http from 'node:http'

const port = process.env.PORT || 3001

const translations = {
  en: {
    route: 'Recommended route: follow signs to Gate C → concourse 3 → elevators to Section 121. Estimated walk: 6 minutes. Current wait at security: 4 minutes.',
    food: 'Nearest vegan stall: GreenBites (Concourse West). Estimated pickup time: 2 minutes. Would you like me to notify them to start preparing?',
    security: 'Recent incidents summary retrieved. INC-204 requires immediate verification. Medical unit ETA: 2 minutes. I recommend escalating to incident command.',
    fallback: 'I can help with venue navigation, queues, accessibility routing, and operational summaries.',
  },
  hi: {
    route: 'अनुशंसित मार्ग: गेट C के संकेतों का पालन करें → कॉनकोर्स 3 → सेक्शन 121 के लिए लिफ्ट। अनुमानित चलने का समय: 6 मिनट। सुरक्षा पर वर्तमान प्रतीक्षा समय: 4 मिनट।',
    food: 'निकटतम शाकाहारी स्टॉल: GreenBites (कॉनकोर्स पश्चिम)। अनुमानित पिकअप समय: 2 मिनट। क्या आप चाहते हैं कि मैं उन्हें तैयारी शुरू करने के लिए सूचित करूं?',
    security: 'घटना का सारांश प्राप्त किया गया। INC-204 को तत्काल सत्यापन की आवश्यकता है। चिकित्सा इकाई ETA: 2 मिनट।',
    fallback: 'मैं स्टेडियम नेविगेशन, कतारों, एक्सेसिबिलिटी मार्ग, और ऑपरेशनल सारांश में मदद कर सकता हूँ।',
  },
}

function getReply(input, language = 'en') {
  const text = input.toLowerCase()
  const lang = translations[language] ? language : 'en'
  if (/gate|seat|section|navigate/.test(text)) {
    return translations[lang].route
  }
  if (/food|pickup|vegan|nearest/.test(text)) {
    return translations[lang].food
  }
  if (/security|incident|summarize/.test(text)) {
    return translations[lang].security
  }
  return translations[lang].fallback
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = ''
    req.on('data', (chunk) => {
      body += chunk
    })
    req.on('end', () => {
      if (!body) resolve({})
      else resolve(JSON.parse(body))
    })
    req.on('error', reject)
  })
}

const server = http.createServer(async (req, res) => {
  const { method, url } = req
  if (method === 'GET' && url === '/health') {
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end(JSON.stringify({ status: 'ok' }))
    return
  }

  if (method === 'POST' && url === '/api/chat') {
    const data = await parseBody(req)
    const reply = getReply(data.input || '', data.language || 'en')
    const payload = {
      reply,
      functionCall: /food|incident|security/.test((data.input || '').toLowerCase())
        ? { name: /food/.test((data.input || '').toLowerCase()) ? 'notifyVendor' : 'createTicket', args: { priority: 'high' } }
        : undefined,
    }
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end(JSON.stringify(payload))
    return
  }

  if (method === 'POST' && url === '/api/execute') {
    const data = await parseBody(req)
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end(JSON.stringify({ status: 'ok', name: data.name, args: data.args }))
    return
  }

  res.writeHead(404, { 'content-type': 'application/json' })
  res.end(JSON.stringify({ error: 'not found' }))
})

server.listen(port, () => {
  console.log(`Backend listening on http://localhost:${port}`)
})
